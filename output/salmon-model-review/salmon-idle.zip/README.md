# Salmon idle

Blender 5.1.2 background-script authoring. One new three-second loop: Salmon_Idle (24fps, frames 1-73).
Small spine/head/arm motion with stationary leg bones. Loop end equals start.
GLB and Blender file preserve the existing Salmon_Walk_InPlace action for movement. FBX contains the active idle only.
Beta lobby exhibit defaults to idle. A movement-state controller selects idle when moving=false and walk when moving=true, crossfading over 0.18 seconds.
Salmon remains a non-playable exhibit; player keyboard movement is not connected to this exhibit. A future playable Salmon must pass its own movement state.
FBX/GLB reimport and browser skeleton/vertex/color/idle-walk-idle transition checks passed.
Source/geometry/color unchanged from the prior rig. No combat animations added.
