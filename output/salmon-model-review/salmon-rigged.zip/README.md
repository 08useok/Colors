# Salmon rig preview

Custom humanoid rig built with Blender 5.1.2 in background script mode.
17 bones, 23 skinned meshes. Body uses spatial two-bone weights; face and bobber attach to head; neck attaches to neck bone.
Original salmon body color #FE7974 is preserved. No Meshy auto-rig or downloaded motion is used.
Original in-place walk: Salmon_Walk_InPlace, frames 1-25, 24fps.
FBX and GLB reimport checks: skeleton, skinned meshes, normalized weights and moving thigh passed.
Beta lobby browser checks: clip playback, actual body vertex movement, normalized weights, original color, match isolation passed.
This is a basic rig/animation test, not a finished combat animation set. Foot planting, complex poses and joint deformation need further refinement. Salmon remains non-playable.
GLB uses Y-up; Blender source uses Z-up. Blender source includes studio camera/lights; exports contain mesh and armature only.
